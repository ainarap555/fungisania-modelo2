import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { InicioComponent } from '../inicio.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav2',
  imports: [RouterModule, CommonModule],
  templateUrl: './nav2.component.html',
  styleUrl: './nav2.component.css'
})
export class Nav2Component {

}
