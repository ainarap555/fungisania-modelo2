import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Nav2Component } from './nav2/nav2.component';
import { Router } from '@angular/router';
import { Producto } from '../../modelos/producto.model';

@Component({
  selector: 'app-inicio',
  imports: [RouterModule, CommonModule, Nav2Component],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent {

}
