import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mi-emprendimiento',
  imports: [RouterModule, CommonModule],
  templateUrl: './mi-emprendimiento.component.html',
  styleUrl: './mi-emprendimiento.component.css'
})
export class MiEmprendimientoComponent {

}
