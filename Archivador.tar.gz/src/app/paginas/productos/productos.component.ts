import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Producto } from '../../modelos/producto.model';
import { Router } from '@angular/router';
import { CarritoService } from '../../servicios/carrito.service';
import { FavoritosService } from '../../servicios/favoritos.service';
@Component({
  selector: 'app-productos',
  imports: [RouterModule, CommonModule],
  templateUrl: './productos.component.html',
  styleUrl: './productos.component.css'
})
export class ProductosComponent {
  Productos: Producto[] = [
    {
      id: 1,
      nombre: "Ramo",
      descripcion: "",
      precio: 11,
      cantidad: 1,
      disponibilidad: true,
      imagen: ""
    },
    {
      id: 2,
      nombre: "Jazmin",
      descripcion: "",
      precio: 10,
      cantidad: 0,
      disponibilidad: false,
      imagen: ""
    },
    {
      id: 3,
      nombre: "Jazmin",
      descripcion: "",
      precio: 12,
      cantidad: 0,
      disponibilidad: true,
      imagen: ""

    },
    {
      id: 4,
      nombre: "rosa",
      descripcion: "",
      precio: 12,
      cantidad: 0,
      disponibilidad: true,
      imagen: ""

    },
  ]

  if(disponibilidad = false) {
    '<p>Sin stock</p>'
  }
//Constructor, donde inyectamos el servicio del carrito
constructor(private carritoService: CarritoService, private favoritosService: FavoritosService){}
//metodo para agregar un producto al carrito
agregarCarrito(producto: Producto){
  //Llama al método del servivio para agregar al producto del carrito
  this.carritoService.agregarAlCarrito(producto);
  //Muestra un mensaje de confirmacion al usuario
  alert('Producto agregado al carrito')
}
agregarFavorito(producto: Producto){
  this.favoritosService.agregarAFavoritos(producto);
  alert('Producto agregado a favoritos')
}

}
